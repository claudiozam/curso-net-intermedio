﻿using ConsoleAppEjemploRestLocal;
using RestSharp;

// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

string url = "http://localhost:5062/api";

var client = new RestClient(url);
var request = new RestRequest("/reclamosrest/7");
var response = client.Get<Reclamo>(request);
Console.WriteLine(response.Id + " - " + response.Titulo);
//Console.WriteLine("Status code: " + response.);
//if (response.IsSuccessful)
//{
//    Console.WriteLine(response.Content);
//
//}
